#include"cChiPheo.h"

void main()
{
	cChiPheo a;
	a.Nhap();
	a.DapChai();
	system("pause"); 
}