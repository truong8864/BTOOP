#include "cChai.h"



cChai::cChai()
{
	iChieuCao = 0;
}

cChai::cChai(int chieucao)
{
	iChieuCao = chieucao;
}

cChai::~cChai()
{
}
