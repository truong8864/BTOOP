#pragma once
#include "cChai.h"
class cChaiHinhLapPhuong :
	public cChai
{
public:
	cChaiHinhLapPhuong(int);
	int DienTich();
	int TheTich();
	cChaiHinhLapPhuong();
	~cChaiHinhLapPhuong();
};

